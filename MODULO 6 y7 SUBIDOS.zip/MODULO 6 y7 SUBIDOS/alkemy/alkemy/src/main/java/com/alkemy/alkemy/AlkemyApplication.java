package com.alkemy.alkemy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlkemyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlkemyApplication.class, args);
	}

}
