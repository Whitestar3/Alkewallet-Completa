package com.alkemy.alkemy;

import static org.springframework.security.config.Customizer.withDefaults;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import com.alkemy.service.CustomUserDetailsService;

/*
 la clase SecurityConfiguration establece cómo la aplicación maneja la autenticación
 y autorización de usuarios, configurando qué recursos están protegidos, cómo se manejan
 los inicios y cierres de sesión, y cómo se gestionan las contraseñas de los usuarios.
 */


@Configuration // Indica que esta clase proporciona configuraciones específicas para la aplicación
@EnableWebSecurity // Habilita la seguridad web en esta aplicación
class SecurityConfiguration {

    @Autowired // Inyecta automáticamente una instancia de CustomUserDetailsService
    CustomUserDetailsService customUserDetailsService;

    @Bean // Define un bean que se puede usar en toda la aplicación
    public static PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Usa BCrypt para codificar las contraseñas
    }

    @Bean // Define otro bean para la configuración de seguridad
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                //.csrf(csrf -> csrf.disable()) // Deshabilita la protección CSRF (descomentarlo si es necesario)
                .authorizeHttpRequests((authorize) -> authorize
                        .requestMatchers("/css/**", "/js/**", "/images/**", "/register", "/error", "/inicio", "/").permitAll() // Permite acceso sin autenticación a estas rutas
                        .requestMatchers("/ordes").authenticated()
                        //.requestMatchers("/admin").hasRole("ADMIN")
                        .anyRequest().authenticated() // Requiere autenticación para cualquier otra solicitud

                )
                .httpBasic(withDefaults()) // Habilita la autenticación básica HTTP
                .formLogin(form -> form
                        .loginPage("/login") // Especifica la página de inicio de sesión personalizada
                        .loginProcessingUrl("/login") // URL a la que se envían las credenciales de inicio de sesión
                        .defaultSuccessUrl("/dashboard", true) // Redirige a /dashboard tras un inicio de sesión exitoso
                        .permitAll() // Permite el acceso a la página de inicio de sesión para todos
                )
                .logout(logout -> logout
                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout")) // Define la URL de cierre de sesión
                        .logoutSuccessUrl("/login?logout") // Redirige a /login?logout tras el cierre de sesión
                        .invalidateHttpSession(true) // Invalida la sesión HTTP
                        .clearAuthentication(true) // Limpia la autenticación
                        .permitAll() // Permite el acceso a la funcionalidad de cierre de sesión para todos
                );

        return http.build(); // Construye y retorna el objeto HttpSecurity configurado
    }

    @Autowired // Inyecta automáticamente el AuthenticationManagerBuilder
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(customUserDetailsService).passwordEncoder(passwordEncoder()); // Configura el servicio de detalles del usuario y el codificador de contraseñas
    }
}
