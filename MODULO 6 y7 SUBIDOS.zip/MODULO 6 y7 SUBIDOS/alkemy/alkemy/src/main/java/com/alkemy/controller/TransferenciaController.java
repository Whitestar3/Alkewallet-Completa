    package com.alkemy.controller;

    import com.alkemy.dto.TransferenciaDto;
    import com.alkemy.model.Banco;
    import com.alkemy.model.Transferencia;
    import com.alkemy.model.User;
    import com.alkemy.repository.UserRepository;
    import com.alkemy.service.BancoService;
    import com.alkemy.service.TransferenceService;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.http.HttpStatus;
    import org.springframework.http.ResponseEntity;
    import org.springframework.security.core.Authentication;
    import org.springframework.security.core.context.SecurityContextHolder;
    import org.springframework.ui.Model;
    import org.springframework.web.bind.annotation.*;

    import java.util.List;


    @RestController
    @RequestMapping("/transferencias")
    public class TransferenciaController {

        @Autowired
        private TransferenceService transferenceService;

        @Autowired
        private UserRepository userRepository;

        @Autowired
        private BancoService bancoService; // Autowire BancoService para acceder a la gestión de bancos

        @PostMapping("/realizar")
        public ResponseEntity<Void> realizarTransferencia(@RequestBody TransferenciaDto transferenciaDto) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            User usuarioOrigen = userRepository.findByUsername(authentication.getName());

            transferenceService.realizarTransferencia(transferenciaDto, usuarioOrigen);

            return new ResponseEntity<>(HttpStatus.OK);
        }

        @PostMapping("/depositar")
        public ResponseEntity<Void> depositarEnCuentaPropia(@RequestBody TransferenciaDto transferenciaDto) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            User usuarioDestino = userRepository.findByUsername(authentication.getName());

            transferenceService.depositarEnCuentaPropia(transferenciaDto, usuarioDestino);

            return new ResponseEntity<>(HttpStatus.OK);
        }

        @PostMapping("/pagar")
        public ResponseEntity<Void> pagarCuenta(@RequestBody TransferenciaDto transferenciaDto) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            User usuarioOrigen = userRepository.findByUsername(authentication.getName());

            transferenceService.pagarCuenta(transferenciaDto, usuarioOrigen);

            return new ResponseEntity<>(HttpStatus.OK);
        }

        @GetMapping("/historico")
        public String mostrarHistorico(Model model) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            User usuarioLogueado = userRepository.findByUsername(authentication.getName());

            List<Transferencia> historico = TransferenceService.obtenerHistoricoPorUsuario(usuarioLogueado.getId());

            model.addAttribute("transacciones", historico);

            return "historico"; // Nombre de la vista Thymeleaf (historico.html)
        }

        @GetMapping("/bancos")
        public String mostrarBancos(Model model) {
            Iterable<Banco> bancos = bancoService.findAll();
            model.addAttribute("bancos", bancos);
            return "bancos"; // Este es el nombre de la vista Thymeleaf (bancos.html)
        }
    }