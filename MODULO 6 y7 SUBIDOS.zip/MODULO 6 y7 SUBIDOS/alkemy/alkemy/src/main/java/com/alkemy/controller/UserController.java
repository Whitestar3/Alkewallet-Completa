package com.alkemy.controller;

import java.security.Principal;

import com.alkemy.dto.UserDto;
import com.alkemy.model.User;
import com.alkemy.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;



@Controller // Marca esta clase como un controlador en Spring MVC
public class UserController {

    @Autowired // Inyecta automáticamente una instancia de UserDetailsService
    private UserDetailsService userDetailsService;

    private UserService userService;

    // Constructor que inyecta una instancia de UserService
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping(value= {"/", "index"}) // Maneja las solicitudes GET para la raíz y /dashboard
    public String index() {
        return "index";
    }

    @GetMapping(value= {"/dashboard"}) // Maneja las solicitudes GET para la raíz y /dashboard
    public String dashboard(Model model, Principal principal) {
        // Obtiene los detalles del usuario autenticado
        UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
        // Añade los detalles del usuario al modelo para la vista
        model.addAttribute("userdetail", userDetails);
        // Retorna el nombre de la vista "dashboard"
        return "dashboard";
    }

    @GetMapping(value= {"/ordes"}) // Maneja las solicitudes GET para la raíz y /dashboard
    public String ordes(Model model, Principal principal) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
        model.addAttribute("userdetail", userDetails);
        return "ordes";
    }

    @GetMapping(value= {"/login"}) // Maneja las solicitudes GET para /login
    public String login(Model model, UserDto userDto) {
        // Añade un objeto UserDto al modelo para el formulario de inicio de sesión
        model.addAttribute("user", userDto);
        // Retorna el nombre de la vista "login"
        return "login";
    }


    @GetMapping(value= {"/register"}) // Maneja las solicitudes GET para /register
    public String register(Model model, UserDto userDto) {
        // Añade un objeto UserDto al modelo para el formulario de registro
        model.addAttribute("user", userDto);
        // Retorna el nombre de la vista "register"
        return "register";
    }

    @PostMapping(value= {"/register"}) // Maneja las solicitudes POST para /register
    public String registerSave(@ModelAttribute("user") UserDto userDto, Model model) {
        User user = userService.findByUsername(userDto.getUsername());

        if(user != null) {
            model.addAttribute("userexist", user);
            return "register";
        }
        // Guarda el nuevo usuario usando el servicio de usuarios
        userService.save(userDto);
        // Retorna el nombre de la vista "register" y agrega el parámetro de consulta "?success"
        return "redirect:/register?success";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        // Obtener el nombre de usuario del usuario autenticado
        UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String username = userDetails.getUsername();

        // Aquí deberías implementar la lógica para obtener el usuario desde el servicio o repositorio
        // y obtener sus detalles incluyendo los saldos de las cuentas

        // Supongamos que obtienes el usuario y sus detalles, incluyendo saldos
        double saldoSilver = 5000.0; // Ejemplo: obtener saldo de cuenta Silver del usuario
        double saldoGolden = 10000.0; // Ejemplo: obtener saldo de cuenta Golden del usuario

        // Agregar los datos al modelo para que Thymeleaf los pueda renderizar en la vista
        model.addAttribute("username", username);
        model.addAttribute("saldoSilver", saldoSilver);
        model.addAttribute("saldoGolden", saldoGolden);

        return "dashboard"; // Nombre de la vista Thymeleaf (dashboard.html)
    }

}

