package com.alkemy.dto;

public class TransferenciaDto {

    private String cuentaDestino;
    private double monto;
    private String descripcion;

    // Getters y setters omitidos para brevedad

    public TransferenciaDto() {
    }

    public TransferenciaDto(String cuentaDestino, double monto, String descripcion) {
        this.cuentaDestino = cuentaDestino;
        this.monto = monto;
        this.descripcion = descripcion;
    }

    // Getters y setters necesarios
}
