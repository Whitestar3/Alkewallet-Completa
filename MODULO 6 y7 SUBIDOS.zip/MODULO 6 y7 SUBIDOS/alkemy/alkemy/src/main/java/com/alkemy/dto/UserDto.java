package com.alkemy.dto;

/* Clase DTO (Data Transfer Object) para transferir datos del usuario entre capas de la aplicación
(por ejemplo, entre la capa de presentación y la capa de servicio). Esto ayuda a mantener una
separación clara entre la lógica de negocio y la lógica de presentación.
*/
public class UserDto {
    // Campos privados que representan los datos del usuario
    private String username;
    private String password;
    private String fullname;
    private String tipoCuenta;

    // Constructor vacío: necesario para frameworks que usan reflexión, como Spring
    public UserDto() {
    }

    // Constructor con parámetros: permite crear una instancia de UserDto con datos iniciales
    public UserDto(String username, String password, String fullname, String tipoCuenta) {
        super();
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.tipoCuenta = tipoCuenta;
    }

    // Getters y setters: métodos para acceder y modificar los campos privados
    public String getUsername() {
        return username;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public void setUsername(String username) {
        this.username = username;
    }



    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }


    public String getFullname() {
        return fullname;
    }


    public void setFullname(String fullname) {
        this.fullname = fullname;
    }


}
