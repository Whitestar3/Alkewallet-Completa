package com.alkemy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*
 La clase User representa una entidad en el sistema de persistencia JPA.
 Esta entidad se mapea a la tabla tranferencia en la base de datos.
 */


@Entity // Indica que esta clase es una entidad JPA que se mapeará a una tabla en la base de datos
@Table(name="tranferencia") // Especifica el nombre de la tabla en la base de datos que corresponde a esta entidad
public class Transferencia {

    @Id // Indica que este campo es la clave primaria de la entidad
    @GeneratedValue(strategy = GenerationType.AUTO) // Configura la estrategia de generación automática del valor de la clave primaria
    private Long idTranferencia;

    private String nombreDestinatario; // Campo almacena el nombre del destinatario
    private String rut; // Campo para almacena el Rut del destinatario
    private String numeroCuenta; // Campo para almacenar el numero de cuenta donde ira el dinero
    private String banco; // campo para almacenar el banco donde ira el dinero
    private String email; // campo para almacenar el email del destinatario
    private String monto; // campo para almacenar el monto a tranfererir

    // Constructor vacío necesario para JPA
    public Transferencia() {
        super();
    }

    // Constructor con parámetros para facilitar la creación de instancias de User con datos iniciales

    public Transferencia(Long idTranferencia, String nombreDestinatario, String rut, String numeroCuenta, String banco,
                         String email, String monto) {
        super();
        this.idTranferencia = idTranferencia;
        this.nombreDestinatario = nombreDestinatario;
        this.rut = rut;
        this.numeroCuenta = numeroCuenta;
        this.banco = banco;
        this.email = email;
        this.monto = monto;
    }

    public Transferencia(String nombreDestinatario, String rut, String numeroCuenta, String banco, String email,
                         String monto) {
        super();
        this.nombreDestinatario = nombreDestinatario;
        this.rut = rut;
        this.numeroCuenta = numeroCuenta;
        this.banco = banco;
        this.email = email;
        this.monto = monto;
    }

    public Long getIdTranferencia() {
        return idTranferencia;
    }

    public void setIdTranferencia(Long idTranferencia) {
        this.idTranferencia = idTranferencia;
    }

    public String getNombreDestinatario() {
        return nombreDestinatario;
    }

    public void setNombreDestinatario(String nombreDestinatario) {
        this.nombreDestinatario = nombreDestinatario;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMonto() {
        return monto;
    }

    public void setMonto(String monto) {
        this.monto = monto;
    }


}
