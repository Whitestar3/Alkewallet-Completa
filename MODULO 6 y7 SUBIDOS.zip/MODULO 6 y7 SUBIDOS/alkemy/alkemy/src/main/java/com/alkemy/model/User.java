package com.alkemy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/*
 La clase User representa una entidad en el sistema de persistencia JPA.
 Esta entidad se mapea a la tabla users en la base de datos.
 */


@Entity // Indica que esta clase es una entidad JPA que se mapeará a una tabla en la base de datos
@Table(name="users") // Especifica el nombre de la tabla en la base de datos que corresponde a esta entidad
public class User {

    @Id // Indica que este campo es la clave primaria de la entidad
    @GeneratedValue(strategy = GenerationType.AUTO) // Configura la estrategia de generación automática del valor de la clave primaria
    private Long id;

    private String username; // Campo para almacenar el nombre de usuario
    private String password; // Campo para almacenar la contraseña
    private String fullname; // Campo para almacenar el nombre completo
    private double saldoSilver; // Saldo de la cuenta Silver
    private double saldoGolden; // Saldo de la cuenta Golden

    // Constructor vacío necesario para JPA
    public User(long l, String username, String password, String fullname, double v, double v1) {}

    // Constructor con parámetros para facilitar la creación de instancias de User con datos iniciales



    public User(Long id, String username, String password, String fullname, String tipoCuenta) {
        super();
        this.id = id;
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.saldoSilver = saldoSilver;
        this.saldoGolden = saldoGolden;
    }



    public User(String username, String password, String fullname, String tipoCuenta) {
        super();
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.saldoSilver = saldoSilver;
        this.saldoGolden = saldoGolden;
    }

    // Getters y setters para acceder y modificar los campos privados


    public void setSaldoSilver(double saldoSilver) {
        this.saldoSilver = saldoSilver;
    }

    public void setSaldoGolden(double saldoGolden) {
        this.saldoGolden = saldoGolden;
    }

    public double getSaldoSilver() {
        return saldoSilver;
    }

    public double getSaldoGolden() {
        return saldoGolden;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getFullname() {
        return fullname;
    }
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }



}
