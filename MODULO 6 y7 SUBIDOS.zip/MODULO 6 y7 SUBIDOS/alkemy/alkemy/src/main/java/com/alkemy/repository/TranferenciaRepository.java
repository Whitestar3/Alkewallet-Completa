package com.alkemy.repository;

import com.alkemy.model.Transferencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.alkemy.model.User;

import java.util.List;

@Repository
public// Marca esta interfaz como un componente de Spring, lo que permite la inyección de dependencias y el manejo de esta interfaz por el contenedor de Spring
interface TranferenciaRepository extends JpaRepository<Transferencia, Long> {

    // Declara un método de consulta personalizado para encontrar un usuario por su nombre de usuario
    User findByUsername(String username);

    List<Transferencia> findByUsuId(Long idUsuario);
}

