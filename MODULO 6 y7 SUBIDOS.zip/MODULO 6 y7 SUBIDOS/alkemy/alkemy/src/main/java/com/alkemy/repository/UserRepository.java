package com.alkemy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.alkemy.model.User;

@Repository // Marca esta interfaz como un componente de Spring, lo que permite la inyección de dependencias y el manejo de esta interfaz por el contenedor de Spring
public interface UserRepository extends JpaRepository<User, Long> {

    // Declara un método de consulta personalizado para encontrar un usuario por su nombre de usuario
    User findByUsername(String username);
}

