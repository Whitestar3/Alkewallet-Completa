package com.alkemy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alkemy.model.Banco;
import com.alkemy.repository.BancoRepository;

@Service
public class BancoService {

    @Autowired
    private BancoRepository bancoRepository;

    public Iterable<Banco> findAll() {
        return bancoRepository.findAll();
    }

    public Banco findById(Long id) {
        return bancoRepository.findById(id).orElse(null);
    }

    public Banco save(Banco banco) {
        return bancoRepository.save(banco);
    }

    public void deleteById(Long id) {
        bancoRepository.deleteById(id);
    }
}
