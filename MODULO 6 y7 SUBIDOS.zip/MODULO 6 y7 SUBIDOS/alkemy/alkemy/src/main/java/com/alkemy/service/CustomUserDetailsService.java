package com.alkemy.service;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.alkemy.model.User;
import com.alkemy.repository.UserRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    //permite la inyección de dependencias de forma automática
    @Autowired
    private UserRepository userRepository;

    // Método requerido por la interfaz UserDetailsService para cargar detalles de usuario por nombre de usuario
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // Buscar al usuario en la base de datos por su nombre de usuario
        User user = userRepository.findByUsername(username);

        // Si el usuario no existe, lanzar una excepción UsernameNotFoundException
        if (user == null) {
            throw new UsernameNotFoundException("Usuario o Password incorrectos");
        }

        // Crear y devolver un objeto UserDetails personalizado que representa al usuario autenticado
        return new CustomUserDetails(user.getUsername(), user.getPassword(), authorities(), user.getFullname());
    }

    // Devuelve la lista de roles/autoridades del usuario (en este caso, solo se asigna el rol USER)
    public Collection<? extends GrantedAuthority> authorities() {
        return Arrays.asList(new SimpleGrantedAuthority("USER"));
    }

}
