package com.alkemy.service;

import com.alkemy.dto.TransferenciaDto;
import com.alkemy.model.Transferencia;
import com.alkemy.model.User;

import java.util.List;

public interface TransferenceService {

    static List<Transferencia> obtenerHistoricoPorUsuario(Long id) {
        return List.of();
    }

    void realizarTransferencia(TransferenciaDto transferenciaDto, User usuarioOrigen);

    void depositarEnCuentaPropia(TransferenciaDto transferenciaDto, User usuarioDestino);

    void pagarCuenta(TransferenciaDto transferenciaDto, User usuarioOrigen);

    List<Transferencia> obtenerHistorico();

    List<Transferencia> obtenerHistoricoDelUsuario(Long idUsuario);
}