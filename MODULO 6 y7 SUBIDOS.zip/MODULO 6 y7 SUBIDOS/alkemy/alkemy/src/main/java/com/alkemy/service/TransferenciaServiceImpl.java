package com.alkemy.service;

import com.alkemy.dto.TransferenciaDto;
import com.alkemy.model.Transferencia;
import com.alkemy.model.User;
import com.alkemy.repository.TranferenciaRepository;
import com.alkemy.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransferenciaServiceImpl implements TransferenceService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void realizarTransferencia(TransferenciaDto transferenciaDto, User usuarioOrigen) {
        // Implementar lógica para realizar la transferencia
    }

    @Override
    public void depositarEnCuentaPropia(TransferenciaDto transferenciaDto, User usuarioDestino) {
        // Implementar lógica para depositar en cuenta propia
    }

    @Override
    public void pagarCuenta(TransferenciaDto transferenciaDto, User usuarioOrigen) {
        // Implementar lógica para pagar una cuenta
    }

    @Override
    public List<Transferencia> obtenerHistorico() {
        return List.of();
    }


    @Autowired
    private TranferenciaRepository transferenciaRepository; // Inject TransferenciaRepository

    @Override
    public List<Transferencia> obtenerHistoricoDelUsuario(Long idUsuario) {
        // Retrieve transactions for the specified user ID
        return transferenciaRepository.findByUsuId(idUsuario);
    }

}
