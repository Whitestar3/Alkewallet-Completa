package com.alkemy.service;

import org.springframework.stereotype.Service;

import com.alkemy.dto.UserDto;
import com.alkemy.model.User;

@Service
public interface UserService {
    User findByUsername(String username);
    User save (UserDto userDto);
}
