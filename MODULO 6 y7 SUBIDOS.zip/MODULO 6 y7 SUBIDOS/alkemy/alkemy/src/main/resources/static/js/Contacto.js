document.getElementById('formularioContacto').addEventListener('submit', function(event) {
    const nombre = document.getElementById('exampleInputNombre').value;
    const correo = document.getElementById('exampleInputEmail').value;
    const descripcion = document.getElementById('exampleFormControlTextarea1').value;
    const archivo = document.getElementById('exampleInputAdjuntar').files[0];
    const mensajeEnvio = document.getElementById('mensajeEnvio');

    if (nombre === '' || correo === '' || descripcion === '') {
        alert('Por favor, completa todos los campos obligatorios.');
        event.preventDefault(); // Evita que se envíe el formulario si hay campos vacíos
    } else {
        // Simular el envío del formulario (aquí podrías enviar los datos al servidor)
        alert('¡Correo enviado!'); // Mostrar una alerta de que el correo se ha enviado
    }
});
