document.addEventListener("DOMContentLoaded", function() {
    const usuarioId = 1; // ID del usuario, este valor debe ser dinámico según el usuario logueado

    // Obtener nombre del usuario
    fetch(`/api/usuarios/${usuarioId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById("nombreUsuario").innerText = data.nombre;
        });

    // Obtener saldo de la cuenta principal
    fetch(`/api/cuentas/usuario/${usuarioId}`)
        .then(response => response.json())
        .then(cuentas => {
            if (cuentas.length > 0) {
                const cuentaPrincipal = cuentas.find(cuenta => cuenta.cuentaTipo === "Principal");
                if (cuentaPrincipal) {
                    document.getElementById("saldoCuentaPrincipal").innerText = cuentaPrincipal.saldo;
                }
            }
        });

    // Obtener saldo de la cuenta internacional en USD
    fetch(`/api/cuentas/usuario/${usuarioId}`)
        .then(response => response.json())
        .then(cuentas => {
            if (cuentas.length > 0) {
                const cuentaInternacional = cuentas.find(cuenta => cuenta.cuentaTipo === "Internacional");
                if (cuentaInternacional) {
                    document.getElementById("saldoCuentaInternacional").innerText = cuentaInternacional.saldo;
                }
            }
        });
});
