// Pago.js

document.getElementById('formularioPago').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
  
    const nombre = document.getElementById('exampleInputNombre').value;
    const email = document.getElementById('exampleInputEmail').value;
    const password = document.getElementById('exampleInputPassword').value;
    const mensajeError = document.getElementById('mensajeError');
  
    let isValid = true; // Flag to track validation status
  
    // Validate name
    if (nombre === '') {
      mensajeError.innerHTML = 'Por favor, ingresa tu nombre.';
      isValid = false;
    }
  
    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      mensajeError.innerHTML = 'Por favor, ingresa una dirección de email válida.';
      isValid = false;
    }
  
    // Validate password length (optional)
    if (password.length < 8) {
      mensajeError.innerHTML = 'La contraseña debe tener al menos 8 caracteres.';
      isValid = false;
    }
  
    if (isValid) {
      // Perform form processing (e.g., send data to a server)
      // You should replace this with your actual logic (AJAX, form submission, etc.)
      console.log('Form submitted successfully!');
      mensajeError.innerHTML = '';
  
      // Redirect to Pago.html after successful validation
      window.location.href = 'pago.html'; // Replace with your desired redirect URL
    }
  });
  