// Event listener for "Elegir Plan Silver" button
document.getElementById('btnElegirSilver').addEventListener('click', function() {
    window.location.href = 'CarroPago.html'; // Cambia 'ruta_de_tu_pagina_plan_silver.html' por la ruta real de tu página
});

// Event listener for "Elegir Plan Gold" button
document.getElementById('btnElegirGold').addEventListener('click', function() {
    window.location.href = 'CarroPago.html'; // Cambia 'ruta_de_tu_pagina_plan_gold.html' por la ruta real de tu página
});
