package com.alkemy.alkemy;

import com.alkemy.model.Banco;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BancoTest {

    @Test
    public void testBancoConstructor() {
        Banco banco = new Banco(1L, "Banco Test");

        assertEquals(1L, banco.getId());
        assertEquals("Banco Test", banco.getNombre());
    }

    @Test
    public void testBancoSettersAndGetters() {
        Banco banco = new Banco();

        banco.setId(1L);
        banco.setNombre("Banco Test");

        assertEquals(1L, banco.getId());
        assertEquals("Banco Test", banco.getNombre());
    }
}
