package com.alkemy.alkemy;

import com.alkemy.model.Transferencia;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TransferenciaTest {

    @Test
    public void testTransferenciaConstructor() {
        Transferencia transferencia = new Transferencia(1L, "nombreDestinatario", "rut", "numeroCuenta", "banco", "email", "1000");

        assertEquals(1L, transferencia.getIdTranferencia());
        assertEquals("nombreDestinatario", transferencia.getNombreDestinatario());
        assertEquals("rut", transferencia.getRut());
        assertEquals("numeroCuenta", transferencia.getNumeroCuenta());
        assertEquals("banco", transferencia.getBanco());
        assertEquals("email", transferencia.getEmail());
        assertEquals("1000", transferencia.getMonto());
    }

    @Test
    public void testTransferenciaSettersAndGetters() {
        Transferencia transferencia = new Transferencia();

        transferencia.setIdTranferencia(1L);
        transferencia.setNombreDestinatario("nombreDestinatario");
        transferencia.setRut("rut");
        transferencia.setNumeroCuenta("numeroCuenta");
        transferencia.setBanco("banco");
        transferencia.setEmail("email");
        transferencia.setMonto("1000");

        assertEquals(1L, transferencia.getIdTranferencia());
        assertEquals("nombreDestinatario", transferencia.getNombreDestinatario());
        assertEquals("rut", transferencia.getRut());
        assertEquals("numeroCuenta", transferencia.getNumeroCuenta());
        assertEquals("banco", transferencia.getBanco());
        assertEquals("email", transferencia.getEmail());
        assertEquals("1000", transferencia.getMonto());
    }
}