package com.alkemy.alkemy;

import com.alkemy.model.User;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    @Test
    public void testUserConstructor() {
        User user = new User(1L, "username", "password", "fullname", 1000.0, 2000.0);

        assertEquals(1L, user.getId());
        assertEquals("username", user.getUsername());
        assertEquals("password", user.getPassword());
        assertEquals("fullname", user.getFullname());
        assertEquals(1000.0, user.getSaldoSilver());
        assertEquals(2000.0, user.getSaldoGolden());
    }

    @Test
    public void testUserSettersAndGetters() {
        User user = new User(1L, "username", "password", "fullname", 1000.0, 2000.0);

        user.setId(1L);
        user.setUsername("username");
        user.setPassword("password");
        user.setFullname("fullname");
        user.setSaldoSilver(1000.0);
        user.setSaldoGolden(2000.0);

        assertEquals(1L, user.getId());
        assertEquals("username", user.getUsername());
        assertEquals("password", user.getPassword());
        assertEquals("fullname", user.getFullname());
        assertEquals(1000.0, user.getSaldoSilver());
        assertEquals(2000.0, user.getSaldoGolden());
    }
}
